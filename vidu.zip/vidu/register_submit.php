<?php
session_start();
include 'config.php';
   if( isset($_POST['submit']) && $_POST["username"] != '' && $_POST["password"] != '' && $_POST["repassword"] != '' && $_POST["Gmail"] != '') {
    $username = $_POST["username"];
    $password = $_POST["password"];
    $repassword = $_POST["repassword"];
    $Gmail = $_POST["Gmail"];
    $level = 0;
    if( $password != $repassword) {
        $_SESSION["thongbao"] =  '<script>alert("Mật khẩu không đúng")</script>';
        header("location:dangky.php");
        die();
    }
    $sql = "SELECT * FROM user WHERE username='$username' ";
    $old = mysqli_query($conn,$sql);
    $password = md5($password);
    if( mysqli_num_rows($old) > 0) {
        $_SESSION["thongbao"] ='<script>alert("Username đã tồn tại")</script>';
        header("location:dangky.php");
        die();
    }
    $regex = "/([a-z0-9_]+|[a-z0-9_]+\.[a-z0-9_]+)@(([a-z0-9]|[a-z0-9]+\.[a-z0-9]+)+\.([a-z]{2,4}))/i"; 
if(!preg_match($regex, $Gmail)) { 
    $_SESSION["thongbao"] =  '<script>alert("Nhập lại email")</script>';
   
    header("location:dangky.php");
    die();
}

$sql1 = "SELECT * FROM user WHERE Gmail='$Gmail' ";
$old1 = mysqli_query($conn,$sql1);
if( mysqli_num_rows($old1) > 0) {
    $_SESSION["thongbao"] =  '<script>alert("email đã sử dụng")</script>';
    header("location:dangky.php");
    die();
}

    $sql = "INSERT INTO user (username,password,Gmail,level) VALUES ('$username','$password','$Gmail','$level') ";
    mysqli_query($conn,$sql);       
   }else {
        $_SESSION["thongbao"] ='<script>alert("Vui lòng nhập đầy đủ thông tin")</script>';
        header("location:dangky.php");
        die();
   }  
       header("location:dangnhap.php");
  
?>              