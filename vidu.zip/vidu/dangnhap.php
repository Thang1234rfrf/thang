<?php
session_start();
if (isset($_SESSION["thongbao"]) ) {
            
  echo $_SESSION["thongbao"];   
         }
?>
        
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {font-family: Arial, Helvetica, sans-serif;}
form {border: 3px solid #f1f1f1;}

input[type=text], input[type=password] {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  box-sizing: border-box;
}

button {
  background-color: #04AA6D;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
}

button:hover {
  opacity: 0.8;
}

.cancelbtn {
  width: auto;
  padding: 10px 18px;
  background-color: #f44336;
}

.imgcontainer {
  text-align: center;
  margin: 24px 0 12px 0;
}

img.avatar {
  width: 40%;
  border-radius: 50%;
}

.container {
  padding: 16px;
}

span.psw {
  float: right;
  padding-top: 16px;
}

/* Change styles for span and cancel button on extra small screens */
@media screen and (max-width: 300px) {
  span.psw {
     display: block;
     float: none;
  }
  .cancelbtn {
     width: 100%;
  }
}
</style>
</head>
<body>

<h2>Login Form</h2>

<form action="login_submit.php" method="POST">
  <div class="imgcontainer">
    <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIIAAACCCAMAAAC93eDPAAAAq1BMVEX///9SlOJNkeF3qulzqOjIyMhBdLH6+vpvpedTl+ZknOP6/P5EeblNleju9Pxpoebz8/NAi9/i4uLa2trOzs7a5/hZmOOWvO05cLFKhMr0+P2LtepNitPX1dPQ1NlElvDk7vrD2PShwu6yzPEfYqvR4fczhN6DsOoYbME5gNKovNcta7O+zuVuksPI1+mGpc5mmtjBzNqzwNOUr9N/qNtfib9SgbuOsd5yn9dfKr5jAAAHS0lEQVR4nO2aaXeiSBSGpUBSLAUia0QcBJcelySaxfz/XzZVqFk6tSJmvvie9ElsudTD3Siu9no33XTTTTd1rJFXlnFclt7o99d2vPm0Tpc69BtBfZlW0/mvkYzKaZUbBoSG/kXktbGspvHVMZy4znUIz6uevXDmwe/kdexcEcCrl0azGPTtJNEAAJp2/Ae0JLF9eARb1t6VAOK0uVjoJ83aP0X+m2BgijTufn0nzon/oa8x1v/AaCggzLuOR1wZ2AE+dj5n+TOFlvjEFVWXnvAqEgFbZv0zhY0hjKqznJjqUDdsrv8pAcEQUJ92Eg0vVfPAd0+kHTgi1g0dqgMcIbD39EszwqlxeietABoI7Ai/vohglMK2Lvh0BEwvaNoeJrAvADg5ArZPiFEOLwjCB0Oiw7ylH0pc2RcDNBC4rZWtfIDrugsAIpzTLfzg5VIEgH/L+GAwcuV8GKUGFJ47WAS2Ydj4l5DUN5TrQoJgoVWxgxuw48SVthAcDaCeqjXrWkgAQP3lska1qHsAaCj1qBiK8iCA5XeTEoqiAaFCr/Z0XXBRwfKn1ZLPADRdl05JJxV1pGBJiasjYkj0VBZhqvt8AmBTL8cTNHPg61M5gpEuSsWAcaapIB1wWchVZmXwT6QBnWWqiwrZqGQIYuHNcTFn2c4XAnjbkKgKpxL25QXbWoCAQ1GJG1QME9FpfLa1II81LZFwQy48S8AprVTUn4CfX+4ELeA02lp4w0qEPbISb9QuQwC2oCg8sRMuRMBu4LfpWmK3Gryw7V/ECMDmtkgnl9gCoXv2Ce6R2B7kvLqMxTslTbP+MLvs6I8lgcBNyFqcCRjh3xXLfvWvBIKWcJJpJBMHzGAy3DAyZQhwJNg3q1ImDhhhzXDDai2H8PeO64umks9O44wazTgbS5mDhF0TleTDk+VmlOsoM1fKCVjM7uQIb/dnjTPzhx9iU9IJWDqrLD3hHeos6z7LNt9O42yy7F7WCcBnNci5TEmeGcz19uHT9GG7NqUJsFibnqnCczRmyNZvjw9xWcYPj2/rTIkAsPJRNhuPDGPXzLJ1tsY/WWa6YwUCDbDyUa4xfTBo9655knuvqRDg5sRAkGtMXyAsbXyPNSZ/KQlAOsGoxVDHaqRsBhJ6i/Y6mepIMtARSvF2ozMFJRUhVkcAJ6kj0LcMKggABFhAS2ysRDu+UiC5FAEvCPxlPZ3HpdeojOfTGj+AEKjfQAgWQTX3aPMFb14B8eSLhzCRsQ6CnPsoEueB1GkmVOtQvPsFIC15AEReJZEUaEi1HQh7TCDzaE7GAyJHWNqAanknuNOAQGo+QVQJ8tIa39ENn7gIgDXeoWnKZ7CeGHYv3GRQIcAM3GEHYj0THngIC8XPd2oeA3pmWO04CLRZJ185JyfRjmE0YecC0JRn+R5ngIvobQFXpc9kkC+GT1VMN1g2vSZxVbLzMSnVEUrmhhy9M2qy13tmIfAmXGwxZ1/MbMT5yAqEWkGexZwHW6xs7PWGrOYEyjYIJSMfrSf6HYJowOgMrN2mQKz9MDqwsrHH7AzAbvUdAIcxO2N2BaLQ/g0EO+QYMSLRLQI3Dr1B/zcQ+jyE3vCdxtApAnpn1wPRYH99hD3XCb1e8URh6BIBPRUCsyHNDa37AtUJ/DjgSEQ6hSFgN3WOnikNGumRIA4MN2jrjTrBJmvlBOyGgnbLdtUZNmuXQvBSCJ2A3UDdPJkz5uybrtXMpJzGmoidgDcuxYrCMDZnjwp7N+9xZlIeS6xVwdysfNWwoGSkNTbX7kayNp3N25pGgPRCxglYxcT6WdDW2M1mrzIQzuZ1ltGGgMCaiHrCWYOIftNupp2rkm9crpo5KG0IiHbigjxrWKQ0hmbauc62q5L1kUi52uIDGHNQlMqGgSgKaQ1KswgEppiZ29UmHjlE5Os0WKN4s9qaM7w+AaAS6GEkT9C769MZCEQzc8UYs9nafXt93W5fX9/c5mXWzGHpAISgL1UNZw2iCWMW24xcXfc4+81OOk6BXZc9iAX+RD4RjhpGE/ZHA2SVZvTrnnQcA3PmwCCZRAqJcFSIGfgzAjL5PQ+ABVNgQsDbMLIZoMRnrzJCsBVBw0DPSWUCfRLJ9qQfDIy6UCUI2/mgYeiHFbr0i6eowqdpS4Drol/srIscgaxd0Veuhb8YJkv1jzw+ZOmTCwnIw00Urto6AlmrMOI/uMjoLuwX0QG1gEDoEBV9uT2KQMN+P9wvVdMSoeU+7F8ahLPuChyNPVTxBEJwj2PQiQuOGkb9qNi8y0Ig9L4vMHdHLvgCEUYHHyFBfVgI+YcIH95VDD5113ii2B2gxcbA78DDflLgQ4fdxeArREEgJrvnF98iHNa3a8ev/Zfn3aTAAMVVABoNcHUQjIbjybbQP42QZT/h1cnyBT5geHEnEFFEBCMqwuEQX3CjohgOQ/w3eePa658pwmY5QnLU6UX4O+ufdDc4XXjzQ1wyuFr4uRwf+j9Wv+mmm66k/wATNZclFWvhWwAAAABJRU5ErkJggg==" alt="Avatar" class="avatar">
  </div>

  <div class="container">
    <label for="uname"><b>Đăng nhập</b></label>
    <input type="text" placeholder="Enter Username" name="username" required>

    <label for="psw"><b>Mật khẩu</b></label>
    <input type="password" placeholder="Enter Password" name="password" required>
        
    <button name="submit" type="submit">Login</button>
    <label>
    </label>
  </div>

  <div class="container" style="background-color:#f1f1f1">
    <button type="button" class="cancelbtn">Cancel</button>
   <button type="button" class="cancelbtn"> <a href="dangky.php">Tạo Tài khoản</a></button>
  </div>
</form>

</body>
</html>
