<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Đăng ký thành viên</title>
</head>
<body>
    <h3>Đăng ký thành viên</h3>
    <p>
        <?php
           if (isset($_SESSION["thongbao"]) ) {
            
            echo $_SESSION["thongbao"];   
                   }
        ?>
    </p>
    <style>
        body {
            background-color:aqua;
        }
        div{
            text-align: center;
        }
    </style>
    <div>
    <form action="register_submit.php" method="POST">
        <table>
            <tr>
             <td>Tên Đăng nhập: </td>
                <td><input type="text" name="username"></td>
            </tr>
            <tr>
                <td>Mật Khẩu: </td>
                <td><input type="password" name="password"></td>
            </tr>
            <tr>
                <td>Nhập lại mật khẩu</td>
                <td><input type="password" name="repassword"></td>
            </tr>
            <tr>
                <td>Gmail: </td>
                <td><input type="text" name="Gmail"></td>
            </tr>
            <tr>
                <td colspan="2">
                    <button type="submit" name="submit">Đăng ký</button>
                    <button type="reset">Làm mới</button>
                </td>
            </tr>
        </table>
    </form>   
    </div>
</body>
</html>