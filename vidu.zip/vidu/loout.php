<?php
session_start();
session_unset("user");
header("logation:dangky.php");  
?>